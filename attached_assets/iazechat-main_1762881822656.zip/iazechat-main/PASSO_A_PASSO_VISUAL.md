# 🎯 GUIA VISUAL - Configuração Cloudflare

## 📺 O QUE VOCÊ VERÁ NA TELA

### PASSO 1: Acessar DNS
```
┌─────────────────────────────────────┐
│  Cloudflare Dashboard               │
├─────────────────────────────────────┤
│  🏠 Home                            │
│  📊 Analytics                       │
│  🔒 SSL/TLS                         │
│  🌐 DNS                    ← CLIQUE │
│  🛡️ Security                        │
└─────────────────────────────────────┘
```

### PASSO 2: Tela de DNS Records
```
┌──────────────────────────────────────────────────────┐
│  DNS > Records                                       │
├──────────────────────────────────────────────────────┤
│                                                       │
│  🔵 Add record                    ← CLIQUE AQUI     │
│                                                       │
│  ┌────────────────────────────────────────────────┐ │
│  │ Tipo   Nome    Conteúdo           Proxy   TTL │ │
│  ├────────────────────────────────────────────────┤ │
│  │ NS     -       ian.ns.cloudflare.com      -   │ │
│  │ NS     -       maya.ns.cloudflare.com     -   │ │
│  └────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────┘
```

### PASSO 3: Adicionar Registro A
```
┌──────────────────────────────────────────────────────┐
│  Add DNS record                                      │
├──────────────────────────────────────────────────────┤
│                                                       │
│  Type                                                │
│  ┌────────────────┐                                 │
│  │ A          ▼   │  ← Selecione "A"                │
│  └────────────────┘                                 │
│                                                       │
│  Name (required)                                     │
│  ┌────────────────┐                                 │
│  │ @              │  ← Digite "@" ou deixe vazio    │
│  └────────────────┘                                 │
│                                                       │
│  IPv4 address (required)                            │
│  ┌────────────────────────────────┐                 │
│  │ 34.57.15.54                    │  ← Digite este IP│
│  └────────────────────────────────┘                 │
│                                                       │
│  Proxy status                                        │
│  ◯ Proxied       ● DNS only  ← SELECIONE DNS only  │
│                                                       │
│  TTL                                                 │
│  ┌────────────────┐                                 │
│  │ Auto       ▼   │  ← Deixe em Auto                │
│  └────────────────┘                                 │
│                                                       │
│  [   Save   ]                    ← CLIQUE           │
│                                                       │
└──────────────────────────────────────────────────────┘
```

### PASSO 4: Resultado Final
```
┌──────────────────────────────────────────────────────┐
│  DNS Records                                         │
├──────────────────────────────────────────────────────┤
│                                                       │
│  ✅ Tudo configurado!                                │
│                                                       │
│  ┌────────────────────────────────────────────────┐ │
│  │ Tipo  Nome   Conteúdo        Proxy    TTL     │ │
│  ├────────────────────────────────────────────────┤ │
│  │ A     @      34.57.15.54     🔴 DNS   Auto    │ │ ← Correto!
│  │ NS    -      ian.ns...       -        -       │ │
│  │ NS    -      maya.ns...      -        -       │ │
│  └────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────┘
```

---

## 🚨 ATENÇÃO: Proxy Status

### ❌ ERRADO (Laranja/Proxied)
```
│ A  @  34.57.15.54  🟠 Proxied  Auto │
                      ↑
                      NÃO USE ISSO!
```

### ✅ CORRETO (Cinza/DNS only)
```
│ A  @  34.57.15.54  🔴 DNS only  Auto │
                      ↑
                      USE ISSO!
```

---

## ⏱️ LINHA DO TEMPO

```
Agora
  │
  ├─── Configurar DNS na Cloudflare (5 min)
  │
  ├─── Aguardar propagação DNS (5-30 min)
  │    └─ Durante este tempo: DNS está se espalhando pela internet
  │
  ├─── Deploy na Emergent (se ainda não fez)
  │    └─ Clique em "Deploy" no painel
  │
  ├─── Vincular domínio na Emergent (5 min)
  │    └─ Deployments → Custom Domain → Link Domain
  │
  ├─── Aguardar verificação (5-15 min)
  │    └─ Emergent verifica se você é dono do domínio
  │
  └─── ✅ PRONTO! Domínio funcionando
       └─ https://suporte.help agora aponta para o novo sistema
```

---

## 🎯 URLs que Funcionarão

Depois de tudo configurado:

```
✅ https://suporte.help              → Tela de login do cliente
✅ https://suporte.help/atendente    → Login do atendente
✅ https://suporte.help/admin        → Login do admin
```

---

## 🔑 CREDENCIAIS

Após migração, use:

**Admin:**
```
URL: https://suporte.help/admin/login
Senha: 102030@ab
```

**Atendente:**
```
URL: https://suporte.help/atendente/login
Login: joao
Senha: 123456
```

**Cliente:**
```
URL: https://suporte.help/
WhatsApp: qualquer número (ex: 5544988294033)
PIN: 2 dígitos (cria no primeiro acesso)
```

---

## 📱 TESTE RÁPIDO

Após 30 minutos, faça este teste:

1. **Abra navegador anônimo** (Ctrl + Shift + N)
2. **Digite:** `https://suporte.help`
3. **Deve aparecer:** Tela de login com logo CYBERTV
4. **Se aparecer site antigo:** Limpe cache e aguarde mais

---

## 🆘 PROBLEMAS?

### Se após 1 hora ainda não funcionar:

1. **Verifique configuração:**
   - Acesse Cloudflare → DNS
   - Confirme que tem registro A com IP 34.57.15.54
   - Confirme que está em "DNS only" (cinza)

2. **Execute teste:**
   ```bash
   /app/verificar_dominio.sh
   ```

3. **Envie print da tela DNS** da Cloudflare

---

## 💡 DICA PRO

Para testar ANTES do DNS propagar:

**Edite arquivo hosts:**

Windows: `C:\Windows\System32\drivers\etc\hosts`
Mac/Linux: `/etc/hosts`

Adicione:
```
34.57.15.54 suporte.help
```

Depois acesse: https://suporte.help

(Remova essa linha depois que DNS propagar!)
